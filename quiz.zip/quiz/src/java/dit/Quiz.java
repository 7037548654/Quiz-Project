/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dit;

import org.w3c.dom.NodeList;

/**
 *
 * @author admin
 */
public class Quiz {
	String[] question=new String[10];
	String[] questionOptions=new String[40];
	String[] correctOptionIndex=new String[10];
        String[] userSelection=new String[10];
        
        public void setUserSelection(int i,String j)
        {
            userSelection[i]=j;
        }
        public String getUserSelection(int i)
        {
            return userSelection[i];
        }

	public String getQuestion(int i)
	{ 
		return question[i];
	}
        public String getCorrectOptionIndex(int i)
	{
		return correctOptionIndex[i];
	}

	public String getQuestionOptions(int j)
	{
		return questionOptions[j];
	}

	public void setQuestion(int i,String s)
	{
		question[i]=s;
	}
	public void setCorrectOptionIndex(int i,String s)
	{
		correctOptionIndex[i]=s;
	}
	public void setQuestionOptions(int j,String s)
	{
		questionOptions[j]=s;
	}
}    
