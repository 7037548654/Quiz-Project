/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dit;

/**
 *
 * @author admin
 */
public class DataModel {
  private String message;
    private registerBean registerBean;
    private loginBean loginBean;
    private boolean hasError;

    public boolean hasError() {
        return hasError;
    }

    public void hasError(boolean hasError) {
        this.hasError = hasError;
    }
    

    public loginBean getLoginBean() {
        return loginBean;
    }

    public void setLoginBean(loginBean loginBean) {
        this.loginBean = loginBean;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    public registerBean getRegisterBean() {
        return registerBean;
    }

    public void setRegisterBean(registerBean registerBean) {
        this.registerBean = registerBean;
    }
    
    
}
  

